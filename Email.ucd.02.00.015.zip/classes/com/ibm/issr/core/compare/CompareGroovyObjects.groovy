package com.ibm.issr.core.compare

class CompareGroovyObjects {
	public final COMPARE_STRING_CASE_SENSITIVE = 1
	public final COMPARE_STRING_CASE_INSENSITIVE = 0
	
	
	private String nameOfObject1
	private def object1
	private String nameOfObject2
	private def object2
	private Closure getNodeOptions

	CompareGroovyObjects setObject1( String nameOfObject, def object ) {
		this.nameOfObject1 = nameOfObject
		this.object1 = object
		return this
	}
	
	CompareGroovyObjects setObject2( String nameOfObject, def object ) {
		this.nameOfObject2 = nameOfObject
		this.object2 = object
		return this
	}

	String isEquivalent( Closure getNodeOptions ) {
		this.getNodeOptions = getNodeOptions
		return isEquivalentElement( "/", "", object1, object2 )
	}

	private String isEquivalentElement( String parentLogicalPath, String parentActualPath, def object1, def object2 ) {	
		if (object1 instanceof Map) {
			if (object2 instanceof Map) {
				return isEquivalentMap( parentLogicalPath, parentActualPath, object1, object2, getNodeOptions )
			} else {
				return "${nameOfObject1} is a map, but ${nameOfObject2} isn't"
			}
		} else if (object2 instanceof Map) {
			return "${nameOfObject2} is a map, but ${nameOfObject1} isn't"
		} else if (object1 instanceof List) {
			if (object2 instanceof List) {
				return isEquivalentArray( parentLogicalPath, parentActualPath, object1, object2 )
			} else {
				return "${nameOfObject1} is an array, but ${nameOfObject2} isn't"
			}
		} else if (object2 instanceof List) {
			return "${nameOfObject2} is an array, but ${nameOfObject1} isn't"
		} else {
			int options = getNodeOptions(parentLogicalPath)
			if ((options & COMPARE_STRING_CASE_SENSITIVE) && (object1 instanceof String) && (object2 instanceof String)) {
				if (object1.equalsIgnoreCase(object2)) {
					return ""
				} else {
					return "${nameOfObject1}${parentActualPath} is not equal to ${nameOfObject2}${parentActualPath} with values of '${object1}' and '${object2}'"
				}
			}
		}
	}
	
	private String isEquivalentMap( String parentLogicalPath, String parentActualPath, def object1, def object2 ) {
		
	}
	
	private String isEquivalentArray( String parentLogicalPath, String parentActualPath, def object1, def object2 ) {
		
	}
}
