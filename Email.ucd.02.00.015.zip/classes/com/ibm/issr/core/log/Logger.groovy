package com.ibm.issr.core.log

import com.ibm.issr.core.plugin.PluginHelper;

/**
 * This is intended to be a very lightweight message logger.  It is
 * modeled after and could easily be integrated with log4j, but this
 * implementation is designed to be more lightweight.  This class contains
 * only static information.
 * @author ltclark
 *
 */
class Logger {
	public static boolean displayTrace = false;
	public static boolean displayDebug = false;
	public static boolean displayInfo = true;
	public static boolean displayWarn = true;
	public static boolean displayError = true;
	public static boolean displayFatal = true;
	public static int tabDepth = 0
	private static String tabOutput = ""
	private static String theLoggingLevel = "info"
	private static int indentationLevel = 0
	private static String indentation = ""
	
	private static Closure abortNotification = null
	
	// The active logging level
	public static LoggerLevel loggerLevel = LoggerLevel.INFO

	/**
	 * Sets the 'indentationLevel' which is the number of tab stops
	 * to put before all trace output.  This is controllable by the code
	 * calling the logging to set readability indentation.	
	 * @param level
	 * @return Returns the previous indentation level
	 */
	public static int setIndentationLevel( int level ) {
		int oldLevel = indentationLevel
		indentationLevel = level
		indentation = ""
		for (int i=0; i<indentationLevel; ++i) {
			indentation = indentation + "\t"
		}
		return oldLevel
	}
	
	/**
	 * Optional ability to set a notification event handler which is called just before the
	 * logger aborts the current application.  This was added so that test code could intercept
	 * and handle abort situations by failing the test.
	 * @param closure The closure, which has one parameter - which is the error message.
	 */
	public static void setAbortNotification( Closure closure ) {
		abortNotification = closure
	}
	
	/**
	 * Increases the indentation level by 1 and returns the previous level.
	 */
	public static int incrementationIndentationLevel() {
		setIndentationLevel( indentationLevel + 1 )
	}
	
	/**
	 * Increments the indentation level by 1 and returns the previous level.
	 */
	public static int incrementIndentationLevel() {
		return incrementationIndentationLevel()
	}
	
	/**
	 * Sets the tab level but only if trace is on.
	 * @param newTabDepth
	 */
	public static void setTraceTabDepth( int newTabDepth ) {
		if (displayTrace) {
			if (newTabDepth > 0) {
				tabDepth = newTabDepth
			} else {
				tabDepth = 0
			}
			tabOutput = ""
			for (int i=0; i<tabDepth; ++i) {
				tabOutput = tabOutput + "\t"
			}
		}
	}
	
	/**
	 * Returns the current trace tab depth.  Note that is automatically set by
	 * the tracing functions.  Use IndentationLevel for manually controlling the indentation/tabbing.
	 */
	public static int getTabDepth() {
		return tabDepth
	}
	
	/**
	 * Sets the logging level to the named level.  The order of the levels is
	 * trace, debug, info, warn, error, fatal.  When you select a level, it
	 * displays that level and the higher level.  For example, if you set the
	 * level to 'debug', it will display all but the 'trace' messages.  Throws
	 * exception if the level doesn't match.
	 * @param level Either blank or one of the logging levels.
	 */
	public static void setLoggingLevel( String level ) {
		boolean found = false;
		level = level.trim().toLowerCase()
		if (level.equals("trace")) {
			found = true;
			displayTrace = true;
		}
		if (level.equals("debug") || found) {
			found = true;
			displayDebug = true;
		}
		if (level.equals("info") || found || level.length()==0) {
			found = true;
			displayInfo = true;
		}
		if (level.equals("warn") || found) {
			found = true;
			displayWarn = true;
		}
		if (level.equals("error") || found) {
			found = true;
			displayError = true;
		}
		if (level.equals("fatal") || found) {
			found = true;
			displayFatal = true;
		}
		if (! found) {
			PluginHelper.abortPlugin( "Logger.setLoggingLevel() called with invalid level of '${level}'")
		}
		theLoggingLevel = level
		loggerLevel = LoggerLevel.lookupLevel(level)
		Logger.debug("Logging level set to '${level}'")
	}
	
	public static String getLoggingLevel() {
		return theLoggingLevel
	}
	
	/**
	 * This is the internal function used to output the message.  This should ONLY be called internally
	 * to this class and ONLY after confirming that the given logging level needs output.
	 * @param label The Logging level label, such as "TRACE"
	 * @param message The logging message.
	 */
	private static void emit( String label, def message ) {
		String prefix = "${label}"
		message.eachLine { line ->
			println "${tabOutput}${indentation}${prefix}: ${line}"
			prefix = "..."
		}
	}
	
	/**
	 * Logs a 'trace' level message.
	 */
	public static void trace( def message ) {
		if (displayTrace) {
			Logger.emit("TRACE", message)
		}
	}
	
	/**
	 * Logs a 'debug' level message.
	 */
	public static void debug( def message ) {
		if (displayDebug) {
			Logger.emit("DEBUG", message)
		}
	}
	
	/**
	 * Logs an 'info' level message.
	 */
	public static void info( def message ) {
		if (displayInfo) {
			Logger.emit("INFO", message)
		}
	}
	
	/**
	 * Logs a 'warn' level message.
	 */
	public static void warn( def message ) {
		if (displayWarn) {
			Logger.emit("WARNING", message)
		}
	}
	
	/**
	 * Logs an 'error' level message.
	 */
	public static void error( def message ) {
		if (displayError) {
			Logger.emit("ERROR", message)
		}
	}
	
	/**
	 * Logs a 'fatal' level message.
	 */
	public static void fatal( def message ) {
		if (displayFatal) {
			Logger.emit("FATAL", message)
		}
	}
	
	
	/**
	 * Prints a message to the designated log level.
	 * @param loggerLevel Log level enumeration, such as LoggerLevel.INFO
	 * @param message The message to print.
	 */
	public static void println( LoggerLevel loggerLevel, def message ) {
		loggerLevel.println message
	}
	
	
	/**
	 * This prints an {@link Exception}/Throwable stack trace by printing the 
	 * stack to the log level associated with loggerLevel.
	 * @param loggerLevel An enumerated value for the appropriate log level, such as LoggerLevel.DEBUG
	 * @param e The exception.
	 */
	public static void printStackTrace( LoggerLevel loggerLevel, Throwable e ) {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		pw.flush()
		sw.flush()
		String stringTrace = sw.toString()
		stringTrace.eachLine { line ->
			loggerLevel.println line
		}
	}
	
	/**
	 * Aborts the application with the given message.  If the logging level is set
	 * to Debug or Trace, then this exits with an Exception.  Otherwise, this logs
	 * an Error message and does a system exit.
	 * @param message Message to display.
	 */
	public static void abortApplicationWithMessage( String message ) {
		if (displayDebug) {
			throw new Exception(message)
		} else {
			Logger.error message
			if (abortNotification) {
				abortNotification message
			}
			System.exit(1)
		}
	}
	
	/**
	 * Aborts the application with the given message and exception.  If the logging level is set
	 * to Debug or Trace, then this exits with an Exception.  Otherwise, this logs
	 * an Error message and does a system exit.
	 * @param message Message to display.
	 * @param e Exception to also display.
	 */
	public static void abortApplicationWithMessage( String message, Throwable e ) {
		if (displayDebug) {
			throw new Exception(message + e.getMessage(),e)
		} else {
			Logger.error message + e.getMessage()
			printStackTrace(LoggerLevel.ERROR, e)
			if (abortNotification) {
				abortNotification message + e.getMessage()
			}
			System.exit(1)
		}
	}
}
