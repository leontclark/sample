package plugin

import javax.activation.DataHandler
import javax.activation.DataSource
import javax.activation.FileDataSource
import javax.mail.*
import javax.mail.Message.RecipientType
import javax.mail.internet.*

import com.ibm.issr.core.log.Logger

class sendEmail extends UCPluginStepImplementation {
	public static void main( java.lang.String[] args ) {
		def stepImpl = new sendEmail()
		stepImpl.performStep(args) {
			stepImpl.execute()
		}
	}

	/**
	 * This function implements the step!!
	 */
	void execute() {

		// *******************************************************
		// ** DEFINE INPUT PARAMETERS HERE
		// *******************************************************

		def recipientList = inProps.recipientList
		def subject = inProps.subject
		def message = inProps.message
		def messageFile = inProps.messageFile
		def isHtml = inProps.isHtml
		def attachments = inProps.attachments
		def emailServerHost = inProps.emailServerHost
		def emailServerPort = inProps.emailServerPort
		def emailSecureServer = inProps.emailSecureServer
		def emailSenderAddress = inProps.emailSenderAddress
		def emailUsername = inProps.emailUsername
		def emailPassword = inProps.emailPassword
		
		// Display a summary of what this plugin is going to do
		Logger.info "Send Email"
		Logger.info "   recipientList = ${recipientList}"
		Logger.info "   subject = ${subject}"
		Logger.info "   message = ${message}"
		Logger.info "   messageFile = ${messageFile}"
		Logger.info "   isHtml = ${isHtml}"
		Logger.info "   attachments = ${attachments}"
		Logger.info "   emailServerHost = ${emailServerHost}"
		Logger.info "   emailServerPort = ${emailServerPort}"
		Logger.info "   emailSecureServer = ${emailSecureServer}"
		Logger.info "   emailSenderAddress = ${emailSenderAddress}"
		Logger.info "   emailUsername = ${emailUsername}"
		super.displayParameters()
		
		Properties props = System.getProperties();
		String protocol
		if (emailSecureServer.equalsIgnoreCase("true")) {
			props.put("mail.smtp.startls.enable",true);
			/* mail.smtp.ssl.trust is needed in script to avoid error "Could not convert socket to TLS"  */
			props.put("mail.smtp.ssl.trust", emailServerHost );
			protocol = "smtps"
		} else {
			props.put("mail.smtp.startls.enable",false);
			protocol = "smtp"
		}
		props.put("mail.smtp.auth", false);
		props.put("mail.smtp.ehlo", false);
		props.put("mail.smtp.host", emailServerHost);
		props.put("mail.smtp.user", emailUsername);
		props.put("mail.smtp.password", emailPassword);
		props.put("mail.smtp.port", emailServerPort);
		
		Session session = Session.getDefaultInstance(props, null);
		MimeMessage mimeMessage = new MimeMessage(session);
		mimeMessage.setFrom(new InternetAddress(emailSenderAddress));
		
		// add recipients
		Logger.debug("Recipients...")
		recipientList.eachLine { recipient, lineNumber ->
			recipient = recipient.trim()
			if (recipient) {
				Logger.debug("   ${recipient}")
				RecipientType recipientType = Message.RecipientType.TO
				if (recipient.toLowerCase().startsWith("cc:")) {
					recipientType = Message.RecipientType.CC
					recipient = recipient.substring("cc:".length()).trim()
				} else if (recipient.toLowerCase().startsWith("bcc:")) {
					recipientType = Message.RecipientType.BCC
					recipient = recipient.substring("bcc:".length()).trim()
				}
				if (recipient.trim()) {
					InternetAddress toAddress = new InternetAddress(recipient.trim());
					mimeMessage.addRecipient(recipientType, toAddress);
				}
			}
		}
		
		mimeMessage.setSubject(subject);

		Multipart multipart = new MimeMultipart()
		
		BodyPart messageBodyPart = new MimeBodyPart()
		if (! message && messageFile) {
			message = (new File(messageFile)).text
		}
		if (isHtml.equalsIgnoreCase("true")) {
			messageBodyPart.setContent(message,"text/html")
		} else {
			messageBodyPart.setText(message);
		}
		multipart.addBodyPart(messageBodyPart)
		
		// Process attachments
		attachments.eachLine { String line ->
			line = line.trim()
			if (line) {
				BodyPart attachmentBodyPart = new MimeBodyPart()
				DataSource source = new FileDataSource(line)
				attachmentBodyPart.setDataHandler( new DataHandler(source) )
				attachmentBodyPart.setFileName(line)
				multipart.addBodyPart(attachmentBodyPart)
			} 
		}

		mimeMessage.setContent(multipart)
		
		try {
			Transport transport = session.getTransport(protocol)
			transport.connect( emailServerHost, emailUsername, emailPassword )
			transport.sendMessage(mimeMessage, mimeMessage.getAllRecipients())
			transport.close()
		} catch (MessagingException e) {
			if (e.getMessage().contains('Unknown SMTP host') ) {
				outProps.put( 'errorCause', 'Unknown SMTP host')
			}
			throw e
		}
	}

}
