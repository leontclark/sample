package com.ibm.issr.core.plugin

/**
 * This exception is thrown by see {@link PluginHelper}.abortPlugin().  The root plugin
 * class should catch this exception type and display the corresponding message.
 * @author ltclark
 *
 */
class AbortPluginException extends Exception {
	public AbortPluginException(String msg) {
		super(msg);
	}
}
